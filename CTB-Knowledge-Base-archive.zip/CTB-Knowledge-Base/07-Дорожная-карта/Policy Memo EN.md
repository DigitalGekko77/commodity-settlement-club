---
tags: [стратегия, policy-memo, english, v3.3]
created: 2026-03-30
updated: 2026-03-30
---

# Policy Memo

## Commodity Settlement Club: Regulatory Expansion Through Trade Infrastructure

**To:** Central bank officials, finance ministry, customs, tax authorities, trade policymakers
**From:** Igor Komkov
**Date:** March 2026
**Classification:** Open — for discussion

---

### 1. Core thesis

A commodity settlement system for sanctioned corridors **does not weaken state control — it strengthens it.** Every institution that currently struggles with opacity in commodity trade gets automatic, real-time visibility and enforcement through the system.

### 2. The problem

Russia–India oil trade ($50B+/year) currently flows through intermediary banks in UAE/Turkey or via bilateral clearing. This creates:

- **For regulators:** Zero visibility into real prices, volumes, and counterparties
- **For the budget:** $500M–1.5B/year in intermediary fees + 5–10% under-collection of export duties due to transfer pricing
- **For customs:** Manual declarations, 3–5 day processing, corruption risk
- **For tax authorities:** Transfer pricing evasion through under-invoicing via intermediaries

### 3. What each institution gets

**Central Bank:**
- Real-time data on every commodity transaction (currently invisible)
- OTC operators licensed as NCOs under CB supervision
- Concentrated, predictable demand for national currency
- Reserve settlement channel (insurance against SWIFT/SPFS blocking)

**Ministry of Finance:**
- Automatic export duty calculation at token redemption (+$2.5–5B/year in collection)
- Real-time budget forecasting (know exact duty income per month)
- Automatic enforcement against transfer pricing (Oracle pricing = market price)

**Customs Service:**
- Auto-generated declarations from smart contract data (3–5 days → hours)
- Real-time cargo tracking via token lifecycle
- Daily trade statistics (currently quarterly)

**Tax Service:**
- OTC operators as tax agents (automatic VAT + profit tax)
- Unified database of all commodity transactions
- Eliminated transfer pricing evasion (Oracle pricing prevents under-invoicing)

**Ministry of Economy:**
- Proactive trade policy (veto over commodity list, volume limits, anti-dumping)
- Real-time data for industrial policy decisions

**Banks:**
- Custody of collateral pools (new revenue)
- OTC lending against token collateral (new credit product)
- Token accounts for corporate clients (differentiation)

**Security services:**
- Full visibility into strategic exports
- No possibility of cargo "loss" or export fragmentation

### 4. Regulatory architecture

| Institution | Role in system | Veto right |
|-------------|---------------|------------|
| Central Bank | Regulator of OTC (NCO license) | Volumes, new countries |
| Ministry of Finance | Observer | Commodity list, duty rates |
| Customs | Integration partner | Classification (TN VED) |
| Tax | Observer | Tax regime |
| Ministry of Economy | Observer | Commodity list |

### 5. Pilot

| Parameter | Value |
|-----------|-------|
| Corridor | Russia → India, crude oil |
| Volume | 50–100 transactions, $50–100M |
| Duration | 6 months |
| Budget | $2M |

### 6. Key message

> This system **does not bypass** government institutions. It **gives them tools they never had**: real-time data, automatic enforcement, and predictive budgeting. It is regulatory expansion, not regulatory circumvention.

---

*CTB-Knowledge-Base v3.3*
