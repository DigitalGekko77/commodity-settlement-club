---
tags: [стратегия, faq, english, v3.1]
created: 2026-03-30
---

# FAQ

## For journalists, policymakers, and skeptics

---

### Q: Is this a sanctions circumvention tool?

**A:** No. The system provides settlement infrastructure for legal trade between sovereign jurisdictions. It does not bypass sanctions — it provides resilience, redundancy, and settlement continuity for trade that is already happening. Countries have the sovereign right to trade. This system makes that trade cheaper, faster, and more transparent.

### Q: Why not just use CIPS or bilateral clearing?

**A:** CIPS (China) and bilateral clearing (INR/RUB) work — but they have limitations. CIPS still routes through Chinese banks, creating single-point dependency. Bilateral clearing in INR exposes Russia to FX risk (rupee is non-convertible). The CTB system provides a neutral, commodity-backed alternative with no dependency on any single monetary center.

### Q: What backs the tokens?

**A:** Digital warehouse receipts — a legal instrument that has existed for 500 years (since Venetian bills of lading). The token does not create new property rights. It digitizes the transfer of existing rights under each jurisdiction's warehouse receipt law (Russia: Civil Code Art. 912, India: WDRA 2007, China: Civil Code Art. 904–918).

### Q: Isn't this just cryptocurrency?

**A:** No. Tokens are:
- Not traded on public exchanges
- Not convertible to fiat through crypto markets
- Not anonymous (full KYC/AML compliance)
- Backed by physical commodities, not speculation
- Operated on a permissioned blockchain (Hyperledger Fabric), not a public chain

### Q: Why start with Russia–India oil?

**A:** India is the largest buyer of Russian oil after China. There is already a baseline (bilateral INR clearing) to compare against. The volume is sufficient for a pilot ($50–100M) but not so large as to attract immediate sanctions pressure. Both countries have a demonstrated interest in reducing USD dependency.

### Q: What if the US sanctions the system?

**A:** The system is fully isolated from the USD zone. No US-connected entities participate. All nodes operate on sovereign infrastructure (air-gap, VPN, sovereign OS if needed). The architecture was stress-tested against this exact scenario (see Stress Test: Hostile State).

**Residual risk:** Companies with US business exposure must choose between systems. For the Russia–India corridor, primary participants do not have US exposure.

### Q: Who controls the system?

**A:** Governance is through a sub-committee of the New Development Bank BRICS (Shanghai). 5 independent experts, appointed by NDB board. No single country controls the system. Decisions require qualified majority (75% for strategic). There is no single-country veto.

### Q: How much does it cost?

**A:** System fee: 0.3% per transaction. For a $100M corridor: $300K. Compare: intermediary routing (UAE/Turkey) costs 1–3% ($1M–3M). Bilateral clearing costs 0.1–0.5% plus FX loss ($500K–1M).

### Q: What happens if an Operator defaults?

**A:** Three layers of protection:
1. Collateral pool (3% of issuance, diversified: gold + bonds + warehouse receipts)
2. System fund (0.3% of transactions)
3. Cross-default clause (default to one = default to all)

### Q: How long until this is operational?

**A:** Phase 0 pilot: 6 months, $2M budget. This produces data from 50–100 real transactions. Not a theoretical model — a working corridor with transaction history.

### Q: Why should anyone trust this?

**A:** Trust is built through the governance model (NDB sub-committee, independent experts), legal basis (existing warehouse receipt law, not new rights), and transparency (open knowledge base, 11 stress tests, full audit trail on blockchain). The system does not ask for trust — it asks for a 6-month pilot with measurable KPIs.

---

*Full documentation: CTB-Knowledge-Base v3.1*
