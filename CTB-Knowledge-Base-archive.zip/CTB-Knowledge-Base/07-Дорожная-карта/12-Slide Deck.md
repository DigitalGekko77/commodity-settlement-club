---
tags: [стратегия, deck, slides, v3.3]
created: 2026-03-30
updated: 2026-03-30
---

# 12-Slide Deck (v3.3)

---

## Slide 1: Title

**Commodity Settlement Club**
*Regulatory expansion through trade infrastructure*

---

## Slide 2: The Problem

- $50B+/year Russia–India oil trade
- Intermediary routing: 1–3% cost, 7–14 days
- **Zero visibility** for regulators (prices, volumes, counterparties)
- $2.5–5B/year lost to transfer pricing
- Manual customs declarations, tax evasion, opaque flows

---

## Slide 3: Core thesis

**This system does not bypass the state. It gives the state tools it never had.**

---

## Slide 4: What each institution gets

| Institution | Benefit |
|-------------|---------|
| Central Bank | Real-time data, NCO supervision, reserve channel |
| Finance Ministry | Auto duties (+$2.5–5B/year), budget forecasting |
| Customs | Auto declarations, cargo tracking, daily stats |
| Tax | Auto VAT/profit tax, unified database |
| Banks | New revenue: custody, lending, token accounts |

---

## Slide 5: How It Works

1. Importer pays → OTC (NCO under Central Bank)
2. OTC issues digital warehouse receipt
3. Transfer → exporter's OTC
4. Redemption → commodity OR convert to national currency
5. Smart contract: escrow, verification, **auto duty/tax calculation**

---

## Slide 6: Regulatory Integration

- OTC = licensed NCO under Central Bank
- Each token = linked to customs declaration
- Smart contract = automatic tax agent
- All operations through CB-supervised bank accounts
- Daily reporting to all regulators

**Not circumvention. Regulatory expansion.**

---

## Slide 7: Unit Economics (per $100M)

| Channel | Cost | Time | Visibility |
|---------|------|------|-----------|
| Intermediary | $1–3M | 7–14d | None |
| Bilateral | $500K–1M | 5–10d | Partial |
| **CTB** | **$300K** | **<72h** | **Full** |

---

## Slide 8: Revenue for Government

| Source | Annual value |
|--------|-------------|
| Recovered duties (transfer pricing) | +$2.5–5B |
| Eliminated intermediary fees | +$500M–1.5B |
| Improved tax collection | +$1–3B |

---

## Slide 9: Governance

- NDB BRICS sub-committee (Shanghai)
- CB observer with veto (volumes, countries)
- Finance Ministry observer with veto (commodity list, duties)
- No single-country dominance, full government oversight

---

## Slide 10: Pilot

| Parameter | Value |
|-----------|-------|
| Corridor | Russia → India, oil |
| Volume | 50–100 transactions |
| Duration | 6 months |
| Budget | $2M |

---

## Slide 11: KPI

| KPI | Target |
|-----|--------|
| Settlement time | <72 hours |
| Cost savings | ≥50% |
| Duty collection | 100% (automatic) |
| Customs processing | Hours (not days) |

---

## Slide 12: What This Is NOT

- ❌ Not a SWIFT replacement
- ❌ Not sanctions circumvention
- ❌ Not a parallel monetary system
- ✅ **Regulatory expansion** — giving government tools it never had
- ✅ Reserve infrastructure for legal trade

---

*To be converted to PowerPoint/Google Slides.*
