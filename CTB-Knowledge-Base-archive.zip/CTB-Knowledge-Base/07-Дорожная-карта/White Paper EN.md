---
tags: [стратегия, white-paper, english, v3.3]
created: 2026-03-30
updated: 2026-03-30
---

# White Paper

## Commodity Settlement Club: Infrastructure for Sanctions-Resilient Trade

**Version:** 3.3
**Author:** Igor Komkov
**Date:** March 2026
**License:** CC-BY-SA 4.0

---

## Abstract

This paper proposes a **commodity settlement club** — a blockchain-based system for settling physical commodity trade between 2–5 jurisdictions. The system uses digital warehouse receipts to facilitate trade settlement at 0.3% cost (<72 hours), compared to 1–3% (7–14 days) through intermediary routing.

**Key innovation:** The system is designed not to bypass government institutions, but to **expand their regulatory reach**. Every institution that could oppose the project — central bank, finance ministry, customs, tax authority — receives a specific role and measurable benefits.

---

## 1. Context

### 1.1 The settlement gap

Russia, India, China, and others face rising costs, delays, and opacity in commodity trade through intermediary banks. For Russia–India oil ($50B+/year): $500M–1.5B in fees, 7–14 day delays, and **zero regulatory visibility**.

### 1.2 Why governments should support this

The system **strengthens state control**:

| Institution | Current state | With CTB |
|-------------|-------------|---------|
| Central Bank | No visibility into commodity flows | Real-time data on every transaction |
| Finance Ministry | 5–10% under-collection of duties | Automatic duty collection (+$2.5–5B/year) |
| Customs | Manual declarations, 3–5 days | Auto-generated, hours |
| Tax Authority | Transfer pricing evasion | Oracle pricing prevents under-invoicing |
| Banks | Losing fees to intermediaries | New revenue: custody, lending, token accounts |

---

## 2. System Design

### 2.1 Core mechanism

1. Importer pays national currency → OTC operator (licensed NCO under Central Bank)
2. OTC issues digital warehouse receipt (token)
3. Token transferred to exporter's OTC
4. Exporter redeems for physical commodity or converts to national currency
5. Smart contract handles: escrow, verification, clearing, **automatic duty/tax calculation**

### 2.2 Regulatory integration

| Institution | Integration |
|-------------|------------|
| Central Bank | OTC = licensed NCO; all operations through CB-supervised bank accounts; daily reporting |
| Finance Ministry | Smart contract calculates export duties at redemption; automatic transfer to budget |
| Customs | Each token linked to customs declaration; auto-generated from contract data |
| Tax Authority | OTC = tax agent; automatic VAT + profit tax calculation and transfer |
| Ministry of Economy | Observer with veto over commodity list |

### 2.3 Governance

- Sub-committee under NDB BRICS (Shanghai)
- 5 members: 3 independent + 2 OTC representatives
- **Central Bank observer with veto** over: issuance volumes, new countries, collateral parameters
- **Ministry of Finance observer with veto** over: commodity list, duty rates
- No single-country dominance, but full government oversight

---

## 3. Economics

### 3.1 Unit economics (per $100M corridor)

| Channel | Cost | Time | Regulatory visibility |
|---------|------|------|---------------------|
| Intermediary (UAE) | $1M–3M | 7–14d | None |
| Bilateral (INR) | $500K–1M | 5–10d | Partial |
| **CTB** | **$300K** | **<72h** | **Full (real-time)** |

### 3.2 Revenue for government

| Source | Estimated annual value |
|--------|----------------------|
| Recovered export duties (transfer pricing) | +$2.5–5B |
| Eliminated intermediary fees | +$500M–1.5B |
| Improved tax collection | +$1–3B (est.) |

---

## 4. Legal Basis

- Token = warehouse receipt (not new property rights)
- Russia: Civil Code Art. 912 ✅
- India: WDRA 2007 ✅ (VDA exclusion needed)
- China: Civil Code Art. 904–918 ✅ (PBOC separation needed)
- Tax: OTC as tax agent (analogous to stock broker)
- Customs: token = linked to customs declaration (mandatory)

---

## 5. Risk Management

| Risk | Protection | Government role |
|------|-----------|----------------|
| Oracle manipulation | Dual-source + DME | CB monitoring |
| OTC default | 3% collateral + 0.3% fund | CB supervision (NCO) |
| Legal failure | Bilateral agreement | Ministry of Justice |
| Sanctions | Full USD-zone isolation | Security services oversight |
| Cyber | Air-gap, VPN, audit | FSB/FSO standards |

---

## 6. Pilot (Phase 0)

| Parameter | Value |
|-----------|-------|
| Corridor | Russia → India |
| Commodity | Crude oil |
| Volume | 50–100 transactions |
| Duration | 6 months |
| Budget | $2M |

---

## 7. What This Is NOT

- ❌ Not a SWIFT replacement
- ❌ Not sanctions circumvention
- ❌ Not a parallel monetary system (tokens = warehouse receipts, not money)
- ❌ Not a weakening of state control
- ✅ **Regulatory expansion** — giving government tools it never had
- ✅ Reserve settlement infrastructure for legal trade

---

*CTB-Knowledge-Base v3.3 | CC-BY-SA 4.0*
