---
tags: [стратегия, executive-summary, english, v3.3]
created: 2026-03-30
updated: 2026-03-30
---

# Executive Summary

## Commodity Settlement Club for Sanctions-Resilient Trade Corridors

---

### Problem

Countries cut off from SWIFT rely on costly, slow, and fragile workarounds: intermediary banks (1–3% fees, 7–14 days), bilateral clearing (FX losses), or barter (no transparency). For the Russia–India oil corridor ($50B+/year), this means $500M–1.5B in annual intermediary costs, chronic settlement uncertainty, and — critically — **zero visibility for regulators** into what is actually being traded, at what price, and with whom.

### Solution

A **commodity settlement club**: blockchain-based settlement for physical commodity trade between 2–5 jurisdictions, using digital warehouse receipts. Not a SWIFT replacement — a specialized tool for corridors where current channels are expensive, slow, or politically vulnerable.

### Why governments should support it

The system **does not bypass state control — it strengthens it.** Every institution that could kill the project gets a role and measurable benefits:

| Institution | What they get |
|-------------|--------------|
| **Central Bank** | Real-time data on commodity flows (currently invisible); OTC operators under CB supervision as licensed NCOs; concentrated demand for national currency; reserve settlement channel if primary systems are blocked |
| **Ministry of Finance** | Automatic export duties on every transaction (est. +$2.5–5B/year in collection); real-time budget forecasting; automatic counter-transfer-pricing enforcement |
| **Customs Service** | Auto-generated declarations (3–5 days → hours); real-time cargo tracking; daily trade statistics (currently quarterly) |
| **Tax Service** | OTC operators as tax agents (automatic VAT + profit tax); unified database of all commodity transactions; eliminated transfer pricing evasion |
| **Ministry of Economy** | Proactive trade policy tool (veto over commodity list); real-time data for industrial policy |
| **Banks** | New revenue: custody of collateral pools, OTC lending against token collateral, token accounts for corporate clients |
| **Security services** | Full visibility into strategic exports; no possibility of cargo "loss" or export fragmentation |

### Key design choices

| Feature | Implementation |
|---------|---------------|
| OTC operators | Licensed NCOs under Central Bank supervision |
| Unit of account | Commodity Basket Unit (oil, metals, gold, food, rare earths) |
| Legal basis | Warehouse receipts (500-year precedent), Incoterms 2020, UNCITRAL |
| Governance | NDB BRICS sub-committee + Central Bank observer with veto |
| Fee | 0.3% (vs 1–3% for intermediaries) |
| Settlement time | <72 hours (vs 7–14 days) |
| Tax/duties | Automatic calculation and transfer at redemption |
| Customs | Auto-integration with national customs systems |

### Pilot

| Parameter | Value |
|-----------|-------|
| Corridor | Russia → India |
| Commodity | Crude oil |
| Volume | 50–100 transactions, $50–100M |
| Duration | 6 months |
| Budget | $2M |

### What this is NOT

- ❌ Not a SWIFT replacement
- ❌ Not sanctions circumvention
- ❌ Not a parallel monetary system (tokens = warehouse receipts, not money)
- ✅ Reserve settlement infrastructure for legal commodity trade
- ✅ Regulatory expansion for every participating institution

---

*Author: Igor Komkov | CTB-Knowledge-Base v3.3 | March 2026*
