---
tags: [риски, значимый, l2, state-channels, v3.1-аудит]
created: 2026-03-30
severity: ЗНАЧИМЫЙ
---

# Слабое место — State Channels избыточны для PoC

> Уровень: **ЗНАЧИМЫЙ**. Для 50-100 сделок за 6 месяцев L2 — оверинжиниринг.

## Проблема

v3.1: «Transaction Layer: State Channels поверх Settlement Layer. 10,000+ TPS.»

### Математика PoC:

- 100 сделок за 6 месяцев = ~0.5 сделки в день
- Fabric 2.5 обрабатывает 3,500 TPS
- **Нагрузка PoC: 0.00001% от мощности Fabric**

State Channels добавляют:
- Сложность разработки (+$200K-400K)
- Дополнительный вектор атаки (dispute resolution для channels)
- Усложнение аудита
- Дополнительную документацию

### State Channels в enterprise (реальность):

- Lightning Network (Bitcoin) — работает, но для микроплатежей
- Raiden (Ethereum) — менее развита
- В enterprise settlement — **ни одного production-деплоймента** State Channels
- Galaxy Digital прогнозирует 25-30% L2-транзакций через State Channels к 2025, но это DeFi, не enterprise

## Предложение

### Фаза 0: без L2

Все транзакции — напрямую на Settlement Layer (Fabric). 3,500 TPS = достаточно для миллионов сделок в год. Для 100 сделок — L2 не нужен.

### Фаза 1 (если >1000 сделок/день):

Рассмотреть ZK-Rollups вместо State Channels:
- ZK-Rollups наследуют безопасность L1
- Приватность (zero-knowledge proofs)
- Batch processing (пакетная обработка) — эффективнее для редких сделок
- Реальные деплойменты в финансах (zkSync, StarkNet)

### Фаза 2+ (если >100,000 сделок/день):

State Channels для повторяющихся пар (ОТП₁-ОТП₂), Rollups для остальных.

## Связи
- L2 → [[Transaction Layer]]
- Архитектура → [[Гибридная блокчейн-архитектура]]
- Обзор → [[MOC — Критический обзор v3.1]]
