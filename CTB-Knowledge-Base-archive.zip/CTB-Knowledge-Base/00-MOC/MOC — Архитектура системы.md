---
tags: [moc, архитектура]
created: 2026-03-29
---

# MOC — Архитектура системы

## Единица стоимости
- [[Commodity Basket Unit (CBU)]] — корзина из 5 товарных групп
- [[Price Oracle v2]] — 7+ источников, trimmed mean, Circuit Breaker

## Блокчейн
- [[Гибридная блокчейн-архитектура]]
  - [[Settlement Layer]] — Hyperledger Fabric (форк), PBFT, расчёты между ОТП
  - [[Transaction Layer]] — State Channels (Layer-2), 10,000+ TPS
  - [[Fallback и Disaster Recovery]] — Tendermint BFT, RTO <4ч
- [[Шардинг]] — географические зоны (Евразия, Африка, ЛатАм)

## Смарт-контракты
- [[TokenFactory]] — выпуск товарных токенов
- [[TradeToken]] — сам токен (ERC-20 аналог)
- [[EscrowVault]] — заморозка при погашении
- [[ClearingEngine]] — многосторонний взаимозачёт
- [[DeliveryOracle]] — подтверждение поставки
- [[DefaultRegistry]] — реестр дефолтов
- [[ReputationRegistry]] — рейтинг участников

## Связи
- Архитектура обслуживает → [[MOC — Механизмы]]
- Должна соответствовать → [[MOC — Стандарты]]
- Проверена через → [[MOC — Стресс-тесты]]
