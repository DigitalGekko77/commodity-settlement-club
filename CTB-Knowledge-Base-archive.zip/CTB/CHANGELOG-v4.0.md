---
tags: [changelog, release, v4]
updated: 2026-07-22
---

# CTB v4.0 — release notes

## Breaking conceptual changes

- CTB is positioned as a regulated multilateral clearing club, not sanctions-proof infrastructure or a parallel currency.
- CBU, PSB, ADC and ETR are distinct; production capacity is not treated as warehouse collateral.
- A two-country corridor is no longer a valid proof of the core multilateral-netting hypothesis.
- Fixed 0.3% fee, 72-hour cycle, 3% collateral and 5% redemption quota are no longer canonical parameters.
- Legal finality is separated from technical commit; taxes and instrument status require jurisdiction-specific opinions.
- Silent consent cannot authorise issuance, collateral release, finality, freeze or default.

## Added

- canonical v4 strategy and audit decision register;
- instrument/finality architecture;
- dynamic margin, hard caps, capped default waterfall and imbalance protocol;
- deterministic netting KPI and Tariff Shock Protocol;
- physical-commodity price stack, selective disclosure and human-controlled AI;
- corridor scorecard, evidence gates and Implementation Readiness Index;
- PFMI evidence profile and OpenAPI 3.1 draft;
- v4 English executive summary, white paper and FAQ;
- new static website and downloadable-release layout.

## Auditor ideas not merged into core

- forced debt-to-bond conversion;
- AALI-based issuance;
- universal MARF mutual guarantee;
- mandatory compute allocation in CBU;
- blanket transaction anonymity.

They remain rejected or gated research items because they add securities, model, liquidity, governance or compliance risk before core settlement is proven.

## Readiness effect

Design readiness rises from an estimated 34% to 70%. Production readiness remains conditional on real participant data, signed LOIs/rulebook, local legal opinions, calibrated risk resources, live integrations and independent tests.
