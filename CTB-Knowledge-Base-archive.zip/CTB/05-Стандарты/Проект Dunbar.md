---
tags: [стандарты, bis, dunbar]
created: 2026-03-29
---

# Проект Dunbar

> BIS Innovation Hub: shared multi-CBDC платформа (Австралия, Малайзия, Сингапур, ЮАР).

Ключевой урок: региональные платформы предпочтительнее глобальной → в ЦТБ v2.0 реализовано через [[Шардинг]].

Источник: [BIS Dunbar](https://www.bis.org/about/bisih/topics/cbdc/dunbar.htm)
