---
tags: [стандарты, fatf, compliance, v3.1]
created: 2026-03-29
updated: 2026-03-30
aliases: [FATF, AML, KYC]
---

# FATF Compliance v3.1

> [!CAUTION]
> Таблица ниже — historical design, не сертификат соответствия. В v4 CDD/R.16/data fields определяются типом платёжной цепочки и местным правом. Изменения FATF R.16, согласованные в июне 2025 года, должны быть реализованы к концу 2030 года; ML даёт alert, а не окончательное решение.

> Базовое соответствие для Фазы 0. Расширенное — Фаза 1+.

## Реализация (Фаза 0)

| Требование | Механизм |
|-----------|----------|
| KYC | Цифровой через госсистемы ID (Россия: Госуслуги, Индия: Aadhaar). 24 часа. |
| CDD | Риск-профилирование. Усиленная проверка >$100K |
| Travel Rule (Rec. 16) | Для транзакций >$1,000: имя, адрес, дата рождения в зашифрованных метаданных |
| Sanctions Screening | Real-time проверка по спискам стран-участниц + UN Consolidated List |
| SAR | Автоматический мониторинг аномалий → ФинМониторинг страны |
| Record Keeping | Блокчейн: 10+ лет. Экспорт в ISO 20022 |

## Расширение (Фаза 1+)

### FATF R.16 update (June 2025)

Новые требования:
- **Chain-wide responsibility:** каждый участник цепочки несёт ответственность за compliance
- **Anti-fraud tooling:** мониторинг за пределами KYC/Travel Rule (поведенческий анализ)
- **Payment transparency:** расширенные требования к метаданным транзакций

### Реализация

| Новое требование | Механизм |
|-----------------|----------|
| Chain-wide responsibility | Смарт-контракт фиксирует compliance-статус каждого участника в цепочке |
| Anti-fraud tooling | ML-модель на поведенческих паттернах (отклонения от baseline) |
| Enhanced metadata | Расширенные поля в транзакциях: purpose code, originator/beneficiary details |

## Соответствие стандартам

| Стандарт | Статус |
|----------|--------|
| FATF Recommendation 15 (Virtual Assets) | Требует квалификации инструмента и участника |
| FATF Recommendation 16 (Payment Transparency) | Design target; подтверждается по всей цепочке |
| FATF R.16 update (June 2025) | ⚠️ Фаза 1+ |
| PFMI (BIS) | ⚠️ Частичное (Фаза 0) → полное (Фаза 2) |

## Связи
- Юридика → [[Юридическая база]]
- Санкции → [[CTB/04-Риски/Защита от санкций]]
- Стратегия → [[MOC — Стратегия v3]]

Источник: [FATF — update to Recommendation 16, 18 June 2025](https://www.fatf-gafi.org/en/publications/Fatfrecommendations/update-Recommendation-16-payment-transparency-june-2025.html).
