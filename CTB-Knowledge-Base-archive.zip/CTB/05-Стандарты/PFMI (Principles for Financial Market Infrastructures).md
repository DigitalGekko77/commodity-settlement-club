---
tags: [standards, bis, pfmi, v4]
updated: 2026-07-22
---

# PFMI: профиль соответствия v4

> PFMI — ориентир проектирования и disclosure, а не самодекларация соответствия. Применимость и надзорный статус определяет компетентный орган.

| Принцип/область | Design v4 | Evidence до production |
|---|---|---|
| Legal basis | rulebook, jurisdiction annex, finality/netting/insolvency opinions | независимые заключения и enforceability analysis |
| Governance | roles, veto, conflicts, default authority | signed charter, fit-and-proper, minutes |
| Comprehensive risk | единый risk taxonomy и limits | approved framework, independent validation |
| Credit/collateral | IM/VM, debit caps, eligible collateral | calibrated models, custody/perfection opinions |
| Liquidity | settlement-window stress и qualifying resources | committed liquid resources и drills |
| Settlement finality | contractual/legal/asset/technical layers | finality opinion и participant tests |
| DvP | ADC/ETR против PSB через atomic/linked escrow | end-to-end test и principal-risk analysis |
| Default management | capped waterfall и recovery/wind-down | funded layers, rulebook, simulation |
| Operational risk | fault domains, key controls, reconciliation | independent audit; critical RTO ≤2h; end-of-day completion |
| Access/tiering | objective risk-based criteria | public criteria и tier monitoring |
| FMI links | rail adapters и due diligence | link agreements, dependency/failure analysis |
| Efficiency | measured netting/cost/adoption | pilot data against baseline |
| Communication | versioned API, ISO 20022 mapping | conformance tests |
| Disclosure | fees, rules, risks, metrics | public disclosure framework |

В прежней версии проценты «соответствия» не имели методологии и исключены.

Источники: [PFMI overview](https://www.bis.org/cpmi/info_pfmi.htm), [Principle 17 assessment](https://www.bis.org/cpmi/publ/d212.pdf).
