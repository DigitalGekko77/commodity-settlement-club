---
tags: [риски, значимый, aml, fatf, санкции, v3.1-аудит]
created: 2026-03-30
severity: ЗНАЧИМЫЙ
---

# Слабое место — AML в санкционном коридоре

> Уровень: **ЗНАЧИМЫЙ**. FATF compliance описан абстрактно. Для коридора с санкционным риском нужна конкретика.

## Проблема

v3.1 описывает FATF compliance на уровне чек-листа (KYC, Travel Rule, SAR, Sanctions Screening). Но:

1. **Россия** — в FATF grey list рисков / под давлением с 2022
2. **Коридор Россия-Индия** — под активным наблюдением OFAC
3. **Абстрактный KYC** недостаточен — нужно прописать конкретно

## Предложение: AML Framework v3.2

### Трёхуровневый KYC:

| Уровень | Кто | Проверки |
|---------|-----|---------|
| **L1: ОТП** | При регистрации ОТП | Государственная лицензия + аудит + sanctions screening (SDN, EU consolidated) |
| **L2: Компании** | При onboarding экспортёра/импортёра | UBO (ultimate beneficial owner) + PEP check + source of funds |
| **L3: Транзакции** | Каждая сделка | STR (suspicious transaction report) если >$5M или нетипичная схема |

### Sanctions Screening:

| Список | Источник | Частота |
|--------|---------|---------|
| OFAC SDN | US Treasury | Real-time (API) |
| EU Consolidated | EU | Real-time (API) |
| UN Security Council | UN | Ежедневно |
| FATF High-Risk Countries | FATF | Ежеквартально |
| National lists (Россия, Индия) | ЦБ стран | Ежемесячно |

### Travel Rule (FATF Rec. 16):

Каждая транзакция содержит:
- Имя отправителя (юрлицо)
- Имя получателя (юрлицо)
- ОТП-отправитель
- ОТП-получатель
- Сумма (в CBU и эквивалент USD)
- Назначение (товар, контракт)

### Anti-Money Laundering:

- Все участники проходят Enhanced Due Diligence (EDD), не Standard DD
- Ежеквартальный отчёт о подозрительных транзакциях → Комитету по товарному клирингу
- Независимый AML-аудит ежегодно (Big 4 или специализированная фирма)

## Связи
- FATF → [[FATF Compliance]]
- OFAC → [[CTB/04-Риски/Слабое место — Санкционный риск OFAC]]
- Обзор → [[CTB/00-MOC/MOC — Критический обзор v3.1]]
