---
tags: [риски, значимый, api, техническое, v3.1-аудит]
created: 2026-03-30
severity: ЗНАЧИМЫЙ
---

# Слабое место — Отсутствие API спецификации

> Уровень: **ЗНАЧИМЫЙ**. Для перехода от концепции к плану нужны интерфейсы.

## Проблема

v3.1 описывает смарт-контракты (TokenFactory, EscrowVault, ClearingEngine, ReputationRegistry, DeliveryOracle, DefaultRegistry), но не определяет:
- API-эндпоинты для взаимодействия ОТП с системой
- Формат сообщений (JSON? Protobuf? ISO 20022?)
- Модель событий (events/notifications)
- Интеграцию с внешними системами (банковские, таможенные, логистические)

## Предложение: минимальная API-спецификация для PoC

### Эндпоинты (REST/gRPC):

| Эндпоинт | Метод | Описание |
|----------|-------|---------|
| `/tokens/issue` | POST | Выпуск токена (ОТП) |
| `/tokens/{id}` | GET | Информация о токене |
| `/tokens/{id}/transfer` | POST | Перевод токена между ОТП |
| `/tokens/{id}/redeem` | POST | Погашение токена товаром |
| `/tokens/{id}/convert` | POST | Конвертация в нацвалюту |
| `/oracle/price` | GET | Текущая цена CBU |
| `/oracle/history` | GET | История цен |
| `/reputation/{otp_id}` | GET | Репутационный рейтинг |
| `/delivery/{id}/verify` | POST | Подтверждение поставки |
| `/disputes/{id}` | POST/GET | Создание/просмотр спора |

### Формат сообщений:

Рекомендация: **ISO 20022** (MX-сообщения) для совместимости с mBridge, CIPS, SWIFT. Конкретно:
- `pacs.008` — перевод средств
- `camt.053` — выписка по счёту
- `pacs.002` — статус

Обёртка: JSON (для простоты PoC), с возможностью перехода на ISO 20022 XML в Фазе 1.

### Events:

| Событие | Триггер |
|---------|---------|
| `TokenIssued` | Выпуск нового токена |
| `TokenTransferred` | Перевод между ОТП |
| `TokenRedeemed` | Погашение товаром |
| `PriceUpdated` | Новая цена Oracle |
| `DeliveryVerified` | Подтверждение поставки |
| `DisputeOpened` | Открытие спора |
| `CircuitBreakerTriggered` | Срабатывание Circuit Breaker |

## Связи
- Смарт-контракты → [[TokenFactory]], [[EscrowVault]], [[ClearingEngine]]
- Oracle → [[Price Oracle v2]]
- Обзор → [[CTB/00-MOC/MOC — Критический обзор v3.1]]
