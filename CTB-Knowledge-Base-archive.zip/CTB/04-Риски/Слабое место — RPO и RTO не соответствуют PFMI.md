---
tags: [риски, значимый, pfmi, disaster-recovery, v3.1-аудит]
created: 2026-03-30
severity: ЗНАЧИМЫЙ
---

# Слабое место — RPO и RTO не соответствуют PFMI

> Уровень: **ЗНАЧИМЫЙ**. BIS PFMI Principle 17 требует RPO ≈ 0 и RTO ≤ 2 часа для системно значимых FMI.

## Проблема

v3.1: «RTO: <4 часа, RPO: <1 час».

### PFMI Principle 17 (Operational risk):

> «An FMI should identify the plausible sources of operational risk... Its systems should be designed to ensure a high degree of security and operational reliability and should have adequate, scalable capacity. Business continuity management should aim for timely recovery of operations and fulfilment of the FMI's obligations, including in the event of a wide-scale or major disruption.»

- **RPO** (Recovery Point Objective): для платёжных систем — **0** или близко к 0. Потеря даже одной транзакции неприемлема.
- **RTO** (Recovery Time Objective): **≤2 часа** для системно важных FMI.

v3.1 не является системно важной FMI (это пилот), но если цель — «уровень BIS/IMF», то нужно соответствовать.

## Предложение

| Параметр | v3.1 | Рекомендация PoC | Рекомендация Фаза 2+ |
|----------|------|-----------------|---------------------|
| RPO | <1 час | <5 минут | 0 (синхронная репликация) |
| RTO | <4 часа | <1 час | <15 минут |
| DR-тест | Ежегодно | Ежеквартально | Ежемесячно |

### Реализация:

- Multi-node Fabric с синхронной репликацией state (RPO ≈ 0)
- Active-Passive кластер (RTO <1 час)
- Автоматический failover (без ручного вмешательства)
- Ежеквартальные DR-учения

## Связи
- PFMI → [[PFMI (Principles for Financial Market Infrastructures)]]
- DR → [[Fallback и Disaster Recovery]]
- Обзор → [[CTB/00-MOC/MOC — Критический обзор v3.1]]
