---
tags: [moc, архитектура]
created: 2026-03-29
---

# MOC — Архитектура системы

> [!IMPORTANT]
> Канонический профиль v4: [[Архитектура v4 — инструменты и окончательность]] и [[Oracle, privacy и AI-control v4]]. State Channels, sharding и второй consensus не входят в PoC.

## Единица стоимости
- [[Commodity Basket Unit (CBU)]] — корзина из 5 товарных групп
- [[Price Oracle v2]] — 7+ источников, trimmed mean, Circuit Breaker

## Блокчейн
- [[LLM-Wiki/wiki/concepts/Гибридная блокчейн-архитектура]]
  - [[Settlement Layer]] — Hyperledger Fabric (форк), PBFT, расчёты между ОТП
  - [[Transaction Layer]] — State Channels (Layer-2), 10,000+ TPS
  - [[Fallback и Disaster Recovery]] — Tendermint BFT, RTO <4ч
- [[Шардинг]] — географические зоны (Евразия, Африка, ЛатАм)

## Смарт-контракты
- [[TokenFactory]] — выпуск товарных токенов
- [[TradeToken]] — сам токен (ERC-20 аналог)
- [[EscrowVault]] — заморозка при погашении
- [[ClearingEngine]] — многосторонний взаимозачёт
- [[DeliveryOracle]] — подтверждение поставки
- [[DefaultRegistry]] — реестр дефолтов
- [[ReputationRegistry]] — рейтинг участников

## Связи
- Архитектура обслуживает → [[MOC — Механизмы]]
- Должна соответствовать → [[MOC — Стандарты]]
- Проверена через → [[MOC — Стресс-тесты]]

## Архитектура CTB

```mermaid
graph TB
    subgraph "Участники"
        A[Участник 1] --> API
        B[Участник 2] --> API
        C[Участник N] --> API
    end
    
    subgraph "API Gateway"
        API[API Gateway] --> Auth[Auth & KYC]
        Auth --> RBAC[RBAC]
    end
    
    subgraph "Transaction Layer (L2)"
        RBAC --> SC[State Channels]
        SC --> TP[10,000+ TPS]
    end
    
    subgraph "Settlement Layer (L1)"
        TP --> CE[ClearingEngine]
        CE --> MF[Hyperledger Fabric / PBFT]
        MF --> SL[Смарт-контракты]
    end
    
    subgraph "Смарт-контракты"
        SL --> TF[TokenFactory]
        SL --> EV[EscrowVault]
        SL --> RE[ReputationRegistry]
        SL --> DR[DefaultRegistry]
    end
    
    subgraph "Оракулы"
        PO[Price Oracle v2] --> CE
        DO[Delivery Oracle] --> EV
    end
    
    subgraph "Fallback"
        MF --> TB[Tendermint BFT]
        TB --> BKP[Disaster Recovery<br/>RTO < 4ч]
    end
```

## Входящие backlinks

> Файлы, которые ссылаются на этот MOC:

```dataview
TABLE file.folder AS "Папка", file.mtime AS "Обновлён"
FROM [[MOC — Архитектура системы]]
SORT file.mtime DESC
```

## Дополнительные материалы (автоматически добавлено)

- [[Гибридная блокчейн-архитектура]]
- [[Товарный токен]]
- [[Упрощённая корзина CBU (PoC)]]


### 09-Диссертация

- [[Письмо Орешкину — v1.0 (backup)]]
- [[Письмо Орешкину — версия для kremlin.ru 1500 — v1.0 (backup)]]
- [[Письмо Орешкину — версия для kremlin.ru — v1.0 (backup)]]
- [[Письмо в Плеханов — v1.0 (backup)]]

### 09-Патент

- [[Заявка на полезную модель]]
- [[Инструкция подачи ФИПС]]
- [[Чертежи]]

### root

- [[CTB/HOME]]
