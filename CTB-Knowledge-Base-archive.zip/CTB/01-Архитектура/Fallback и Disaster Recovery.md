---
tags: [архитектура, блокчейн]
created: 2026-03-29
---

# Fallback и Disaster Recovery

> Компонент [[LLM-Wiki/wiki/concepts/Гибридная блокчейн-архитектура|гибридной блокчейн-архитектуры]].
