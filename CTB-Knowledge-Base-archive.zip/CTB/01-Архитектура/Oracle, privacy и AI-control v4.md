---
tags: [oracle, privacy, ai, security, v4, canonical]
updated: 2026-07-22
status: canonical
---

# Oracle, privacy и AI-control v4

## Price stack

Для каждого commodity profile задаются:

`reference benchmark + location basis + quality differential + freight/insurance + FX + timestamp adjustment`.

Источник проходит liquidity, governance, availability, manipulation и sanctions-dependency assessment. Один и тот же процент внешних бирж не подходит нефти, зерну, электричеству и физическим металлам.

## Quorum и fallback

- минимум два независимых пути данных и один независимый validation source;
- stale window и confidence score;
- robust aggregation после нормализации единиц и времени;
- breaker при расхождении, low liquidity или невозможности рассчитать basis;
- fallback hierarchy заранее опубликована; 30-дневная средняя не применяется автоматически при market break;
- ручной override требует dual control, reason, expiry и последующего review.

## Delivery oracle

Не пытается «узнать правду из блокчейна». Он собирает подписанные доказательства склада/перевозчика/инспектора, проверяет uniqueness/control/integrity, сопоставляет quantity/quality и передаёт exception человеку. Ответственность источника закреплена contract/SLA.

## Privacy model

Данные классифицируются по ролям:

- участник видит собственную сделку и необходимый status;
- контрагент — согласованный trade set;
- оператор — данные для исполнения и risk management;
- регулятор/аудитор — полномочия по закону и immutable access log;
- публика — только агрегаты без re-identification risk.

Базовый механизм: encryption in transit/at rest, field-level access, private collections, pseudonymous operational IDs, key separation, retention/deletion schedule и audited emergency access.

ZK/commitment применяется только если конкретный атрибут можно доказать без раскрытия (например, `margin ≥ requirement`) и независимый аудит подтверждает soundness. «Полная анонимность» не является целью.

## AI control plane

Допустимые функции:

- OCR/document matching и поиск несоответствий;
- anomaly detection в ценах, маршрутах, связях и поведении;
- entity resolution и case prioritisation;
- simulation/stress scenario generation;
- explainable recommendation оператору.

Запрещено без human approval:

- выпуск/сжигание ADC;
- freeze/unfreeze;
- признание sanctions match или дефолта;
- изменение цены, margin model или лимита;
- передача данных новому получателю.

Для каждой модели ведутся owner, purpose, data lineage, version, validation, threshold, false-positive/negative metrics, drift, override и rollback.

## Cyber baseline

STRIDE/threat scenarios покрывают participant compromise, insider, custodian fraud, oracle collusion, key theft, data poisoning, ransomware, ledger split, denial of service и supply chain. До production обязательны independent penetration test, key ceremony, restore exercise, 2-hour recovery test, incident disclosure SLA и controlled bug bounty.

## Post-quantum roadmap

Сначала crypto inventory и crypto-agility. Затем тест hybrid signatures с **ML-DSA (FIPS 204)** там, где PKI/HSM/latency это поддерживают. Нельзя обещать «Dilithium phase 1» без end-to-end interoperability и operational recovery.
