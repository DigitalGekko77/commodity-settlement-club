---
tags: [strategy, outreach, executive-brief, english, v4, canonical]
updated: 2026-07-22
---

# CTB v4 — Institutional Outreach Brief

## The proposition

**CTB is a regulated pre-clearing layer for recurring cross-border commodity obligations.** It validates which obligations may be netted, calculates multilateral net positions and links the residual settlement to prefunded balances and verifiable commodity title. It does not introduce a new currency and it does not replace banks, CIPS, CBDC or other lawful settlement rails.

## The problem worth testing

Cross-border commodity trades are commonly funded and settled as separate gross bilateral obligations. Where three or more recurring participants form a compatible obligation graph, this can create avoidable peak liquidity, repeated transfers, fragmented reconciliation and duplicated title checks.

The opportunity should not be assumed. It should be measured on real historical data after timing, currency, legal entity, insolvency, commodity-title and regulatory constraints are applied.

## What CTB contributes

1. **Eligibility and legal netting sets** — only compatible obligations enter the same netting calculation.
2. **Multilateral optimisation** — residual positions are calculated under debit, concentration, tenor and participant limits.
3. **Risk resources** — prefunding, dynamic margin and a capped default waterfall allocate losses before live settlement.
4. **Title-linked delivery** — an ADC exists only against verified control over an identified commodity lot or recognised ETR.
5. **Auditable orchestration** — source evidence, exclusions, approvals, overrides and residual settlement instructions share one reproducible trail.

## What CTB does not claim

- no new reserve currency or publicly traded token;
- no immunity from sanctions, export controls, licensing or applicable law;
- no asset claim against future production capacity;
- no guaranteed fee, settlement time or saving before replay and pilot evidence;
- no regulator-blind anonymity and no autonomous AI decisions.

## Proposed first engagement

A **30-minute technical scoping call** to identify one candidate corridor and one institutional owner. If there is a plausible fit, the next step is a bounded historical replay:

- anonymised obligations from at least three recurring participants;
- no movement of money or title;
- reproducible baseline versus constrained multilateral netting;
- legal and data screening before any shadow or live pilot;
- a stop decision if the benefit is immaterial or the obligations are not enforceably compatible.

## Decision produced

The replay answers a narrow institutional question: **does this corridor contain enough legally usable multilateral offset to justify the cost of a regulated pilot?** The output is a measured netting ratio, peak-liquidity reduction, exception inventory, corridor-specific risk map and go/no-go recommendation.

## Author

**Igor Komkov**  
Author, Commodity Clearing Club (CTB)  
[pointofart.ru/index-en.html](https://pointofart.ru/index-en.html) · [GitHub specification](https://github.com/DigitalGekko77/commodity-settlement-club)  
[idkomkov@gmail.com](mailto:idkomkov@gmail.com)

