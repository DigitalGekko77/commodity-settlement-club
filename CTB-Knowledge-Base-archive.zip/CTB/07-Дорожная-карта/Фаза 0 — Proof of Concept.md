---
tags: [roadmap, poc, v4]
updated: 2026-07-22
status: superseded-by-scorecard
---

# Фаза 0 — discovery и proof of value v4

> Канон: [[Scorecard коридора и PoC v4]]. Россия–Индия/нефть больше не назначается автоматически.

## 12–16 недель до live pilot

1. Собрать анонимизированный graph обязательств 3+ участников за 6–12 месяцев.
2. Replay netting с реальными сроками, валютами, товарами и legal netting sets.
3. Провести 20+ problem interviews и получить минимум 3 LOI с data/budget owner.
4. Составить legal red-flag memo по 2–3 кандидатным коридорам.
5. Проверить ETR/title chain, oracle stack и доступные settlement rails.
6. Построить thin-slice prototype без реального выпуска и денег.
7. Выбрать коридор scorecard, утвердить capped pilot или закрыть гипотезу.

## Бюджет

Не фиксируется в USD до scope/LOI. Budget baseline включает data/legal discovery, model replay, prototype, security review и participant integration. Отдельно показываются one-off и recurring costs.

## Go/no-go

No-go при отсутствии трёхстороннего netting potential, legal finality, проверяемого title/control, anchor participants или приемлемого sanctions/AML risk appetite.
