---
tags: [readiness, implementation, audit, v4, canonical]
updated: 2026-07-22
status: canonical
---

# Implementation Readiness Index v4

## Шкала

0 — отсутствует; 1 — тезис; 2 — проект; 3 — проверено на данных/макете; 4 — независимо проверено; 5 — работает в production.

| Контур | v3.3 | v4.0 design | До pilot-ready |
|---|---:|---:|---|
| Value proposition/netting | 2 | 4 | historical replay + buyer interviews |
| Legal instruments/finality | 1 | 3 | country opinions + signed rulebook |
| Credit/liquidity/default | 2 | 4 | calibration + funded resources + insurer terms |
| Oracle/title controls | 2 | 4 | data contracts + live prototype + validation |
| Technology/API | 2 | 3 | ADR, reference implementation, benchmark |
| Cyber/resilience | 1 | 3 | threat test, pen test, 2h recovery exercise |
| AML/privacy/data | 2 | 4 | jurisdiction mappings + operational cases |
| Corridor/adoption | 1 | 3 | data access, LOI, sponsor, willingness to pay |
| Governance/operations | 2 | 3 | named entities, staffing, escalation drills |
| Evidence/disclosure | 2 | 4 | independent review and public disclosure |

**Итого:** v3.3 ≈ 34%; v4.0 как проект ≈ 70%. Это не означает 70% готовности production: критические gates мультипликативны. Без legal finality, anchor participants и funded risk resources запуск остаётся no-go.

## Что стало полезнее

- stakeholder может отличить проверенное решение от гипотезы;
- юрист получает перечень точных вопросов вместо лозунга «warehouse receipt»;
- risk officer видит exposure, margin, caps и loss allocation;
- архитектор получает минимальный PoC и API boundary;
- sponsor может остановить проект на gate до крупных затрат;
- инвестор/государство видит честные KPI и не покупает неподтверждённые 0,3%/72 часа.

## Путь к «10/10 по возможностям»

10/10 — не максимум функций, а максимум полезных опционов без скрытого tail risk:

1. доказать netting на реальных данных;
2. закрыть legal finality и title control;
3. профинансировать waterfall;
4. провести neutral live pilot;
5. добавить rails adapters;
6. затем отдельно испытывать service/compute claims, ZK и trade finance.

Каждая новая возможность должна быть отключаемой, лимитированной и не ухудшать core settlement.
