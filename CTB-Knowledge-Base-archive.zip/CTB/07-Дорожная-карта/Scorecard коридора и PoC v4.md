---
tags: [poc, corridor, scorecard, roadmap, v4, canonical]
updated: 2026-07-22
status: canonical
---

# Scorecard коридора и PoC v4

## Сначала данные, потом флаг

Кандидат оценивается по 0–5, с evidence/owner/date. Политическое удобство не заменяет подписанного участника и legal opinion.

| Критерий | Вес | Go/no-go |
|---|---:|---|
| Реальные трёхсторонние взаимные потоки и netting potential | 20% | replay данных показывает материальный эффект |
| Готовность 3+ anchor participants | 15% | LOI + data sharing + budget owner |
| Legal finality/netting/ETR | 15% | нет критического prohibition |
| AML/sanctions/export-control feasibility | 10% | documented risk appetite |
| Commodity standardisation и verifiable title | 10% | пригодный ETR/control chain |
| Oracle/hedging/market depth | 10% | replicable price stack |
| Settlement rails и trapped-liquidity risk | 10% | tested funding/exit route |
| Technology/data residency/cyber | 5% | deployable target architecture |
| Sponsor/operations | 5% | named operator и accountable executives |

Россия–Индия, Бразилия–Индия и Индия–ОАЭ остаются **кандидатами**, а не решением. Санкционно чувствительный коридор имеет смысл только после proof на более нейтральном контуре или при явном sponsor/risk appetite.

## PoC scope

- 3–7 юридических лиц и минимум три стороны потока;
- исторический replay → shadow mode → capped live pilot;
- 1–2 однородных товара;
- PSB + ADC/ETR, без публичной торговли;
- один rulebook, jurisdiction annex на каждую страну;
- один technology stack, ручной fallback и reconciliation;
- независимые legal, model и security reviews.

## KPI без заранее нарисованного успеха

| Группа | Метрика |
|---|---|
| Netting | ratio, peak liquidity reduction, residual transfers |
| Settlement | finality time, failure/reversal/dispute rate |
| Economics | total cost incl. collateral/integration/compliance; baseline comparison |
| Risk | margin breaches, uncovered exposure, concentration, loss events |
| Oracle/title | stale data, exceptions, false alerts, duplicate/lien attempts |
| Operations | availability, RTO/RPO test, reconciliation breaks |
| Compliance | alert quality, case time, mandatory-data completeness |
| Adoption | active users, repeat volume, willingness to pay |

## Exit criteria

Расширение разрешено, если:

- legal opinions не содержат незакрытых fatal qualifications;
- netting/liquidity benefit устойчив в нескольких settlement windows;
- total cost ниже согласованного baseline после учёта капитала;
- нет uncovered principal exposure;
- 2-hour recovery и end-of-day completion испытаны;
- участники подписали production rulebook и funding commitments.

Иначе пилот закрывается контролируемо, данные экспортируются, PSB/ADC погашаются, причины публикуются в lessons learned.
