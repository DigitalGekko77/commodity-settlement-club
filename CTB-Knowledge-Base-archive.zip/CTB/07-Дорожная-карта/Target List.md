---
tags: [стратегия, outreach, target-list, v3.1]
created: 2026-03-30
---

# Target List — 20 Recipients

> For private circulation. Personalized outreach (written, no meetings).

---

## Tier 1: Dissertation channel (NEW)

| # | Organization | Contact point | Why | Personalization angle |
|---|-------------|--------------|-----|----------------------|
| 1 | **Maksim Oreshkin** | Presidential rep for BRICS | Ex-Plekhanov gold standard group; now has mandate | "System solves what gold standard couldn't: volatility, legal basis, CB integration" |
| 2 | **Plekhanov University** | Dean of Higher School of Finance | Dissertation advisor potential | "Ready-made dissertation: 120 docs, 11 stress tests, 3 jurisdictions" |
| 3 | **Plekhanov University** | Dept. of International Monetary Relations | Direct relevance to their research | "Commodity settlement as alternative to gold standard" |

## Tier 2: Institutional (direct relevance)

| # | Organization | Contact point | Why | Personalization angle |
|---|-------------|--------------|-----|----------------------|
| 1 | **New Development Bank BRICS** | Research Division, Shanghai | Natural sponsor; mandate for infrastructure finance | "Pilot-scale commodity settlement aligned with NDB mandate" |
| 2 | **Central Bank of Russia** | Dept. of International Operations | Direct stakeholder | "Reduces intermediary dependency for Russia–India oil trade" |
| 3 | **RBI (India)** | International Dept., Mumbai | Direct stakeholder | "Settlement infrastructure for India's largest oil import corridor" |
| 4 | **Vnesheconombank (VEB.RF)** | Strategy Dept. | Russian development bank, potential CSO | "New instrument for trade finance in sanctioned environment" |
| 5 | **Russia-China Investment Fund (RCIF)** | Moscow/Beijing | Cross-border finance expertise | "Bridge between Russian and Chinese commodity settlement" |

## Tier 2: Think tanks & academics

| # | Organization | Contact point | Why | Personalization angle |
|---|-------------|--------------|-----|----------------------|
| 6 | **RSMD (РСМД)** | Moscow | Russian foreign policy think tank | "Intellectual infrastructure for BRICS financial architecture" |
| 7 | **Carnegie Russia Eurasia Center** | Berlin/Washington | International credibility | "Pilot for post-SWIFT commodity settlement" |
| 8 | **Brookings Institution** | Global Economy program | Policy influence | "Commodity-backed settlement: alternative to CBDC-only approach" |
| 9 | **Chongyang Institute (人大重阳)** | Beijing | Chinese BRICS policy | "Neutral settlement layer for Sino-Russian commodity trade" |
| 10 | **Observer Research Foundation (ORF)** | New Delhi | Indian foreign policy | "India's settlement infrastructure options beyond USD" |
| 11 | **HSE (Вышка)** | Faculty of Economics | Academic co-author potential | "Research partnership: unit economics of commodity settlement" |
| 12 | **IIM Ahmedabad** | Finance area | Indian academic credibility | "Comparative analysis: CTB vs bilateral clearing" |

## Tier 3: Media & industry

| # | Organization | Contact point | Why | Personalization angle |
|---|-------------|--------------|-----|----------------------|
| 13 | **РБК** | Economic desk | Russian business media | "How Russia–India oil trade can be 3x cheaper" |
| 14 | **Коммерсантъ** | Economics | Russian business media | "Commodity settlement: the missing layer in BRICS finance" |
| 15 | **Economic Times** | Policy desk | Indian business media | "India's $50B oil import: new settlement tool" |
| 16 | **Caixin Global** | English desk | Chinese financial media | "Beyond CIPS: corridor-specific settlement" |

## Tier 4: Technology & blockchain

| # | Organization | Contact point | Why | Personalization angle |
|---|-------------|--------------|-----|----------------------|
| 17 | **Hyperledger Foundation** | Linux Foundation | Technical validation | "Enterprise blockchain for commodity settlement" |
| 18 | **BIS Innovation Hub** | Singapore/Beijing | CBDC project comparison | "Complementary to mBridge: the commodity layer" |

## Tier 5: Existing BRICS financial institutions

| # | Organization | Contact point | Why | Personalization angle |
|---|-------------|--------------|-----|----------------------|
| 19 | **BRICS Business Council** | Financial Services working group | Institutional access | "Proposal for Financial Services working group" |
| 20 | **Contingent Reserve Arrangement (CRA)** | Technical team | Existing BRICS financial mechanism | "Commodity settlement as complement to CRA" |

---

## Outreach protocol

1. Send: Executive Summary (1 page) + cover letter (personalized)
2. Follow-up: 7 days later if no response
3. If interest: send Policy Memo + offer full knowledge base
4. No cold calls, no meetings, no pressure
5. Track: opened / responded / interested / declined

## Cover letter template

> Subject: Commodity Settlement Club — pilot proposal for [corridor/topic]
>
> [Name],
>
> I've developed a detailed proposal for a commodity settlement system designed for trade corridors where SWIFT-based channels are unavailable or impractical.
>
> The core idea: a 6-month pilot for Russia–India oil settlement, saving 50%+ vs current intermediary routing, with full legal enforceability under existing warehouse receipt law.
>
> This is not a SWIFT replacement or a sanctions circumvention tool. It's reserve settlement infrastructure for legal trade.
>
> I'm attaching a 1-page summary. Full documentation (70+ documents, 11 stress tests) available on request.
>
> Happy to provide additional detail by email.
>
> Best regards,
> Igor Komkov

---

*CTB-Knowledge-Base v3.1*
