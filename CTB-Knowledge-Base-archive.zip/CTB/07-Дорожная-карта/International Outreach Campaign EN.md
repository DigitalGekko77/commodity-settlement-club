---
tags: [strategy, outreach, email, english, v4, canonical]
updated: 2026-07-22
status: drafts-prepared-not-sent
---

# CTB v4 — International Outreach Campaign

## Campaign objective

Secure one **30-minute technical scoping call** and one institutional owner willing to examine a bounded historical replay. The first contact does not ask for funding, live settlement, confidential data or political endorsement.

## Message discipline

- CTB is a **regulated multilateral pre-clearing layer**, not digital barter.
- It is not a new currency and does not compete with CIPS, banks, CBDC or other settlement rails.
- Historical replay precedes legal design, infrastructure and any movement of money or title.
- All fee, speed and saving figures remain hypotheses until measured against a real baseline.
- The institutional decision is a go/no-go on a shadow pilot, not adoption of the full architecture.

## Prepared recipients

| Priority | Institution | Verified channel | Specific fit | Draft subject |
|---:|---|---|---|---|
| 1 | India Exim Bank, Research & Analysis Group | `gaurav@eximbankindia.in` | Countertrade research, trade finance, international corridors | Proposal: historical replay of multilateral commodity-trade obligations |
| 2 | IFSCA FinTech Sandbox, India | `fe-sandbox@ifsca.gov.in`; cc `abhishek.faujdar@ifsca.gov.in`, `development@ifsca.gov.in` | TechFin/sandbox jurisdiction for international financial services | Pre-application enquiry: multilateral commodity pre-clearing historical replay |
| 3 | ADGM Digital Lab, UAE | `fintech@adgm.com` | Institutional collaboration using synthetic/anonymised data | Digital Lab proposal: multilateral trade-obligation netting and title-linked settlement |
| 4 | AFSA FinTech Lab, AIFC | `fintechlab@afsa.kz`; cc `info@afsa.kz` | Controlled testing under an English-common-law framework | FinTech Lab scoping proposal: commodity-trade pre-clearing historical replay |
| 5 | CIPS Co., Ltd. | `kjqs@cips.com.cn`; cc `fwb@cips.com.cn` | Residual RMB/HKD settlement after upstream netting | Technical dialogue proposal: pre-clearing optimisation compatible with CIPS |

## Recommended sequence

**Wave 1:** India Exim Bank, IFSCA and ADGM. They can evaluate the concept even before a bank consortium exists and are plausible sources of a sponsor, corridor or sandbox route.

**Wave 2:** AFSA/AIFC. It is a credible alternative jurisdiction if India–UAE channels do not produce an owner or if the legal-operating model benefits from an AIFC test environment.

**Wave 3:** CIPS. The message should be sent as a compatibility and routing enquiry, not as a direct participation application. A referral from a bank, regulator or sandbox materially improves the chance of substantive review.

The five drafts may also be sent together if breadth is more important than sequencing. A staggered campaign makes follow-up and message refinement easier.

## Attached material

- `CTB-Outreach-Brief-EN.pdf` — two pages; primary first-contact attachment.
- [[Institutional Outreach Brief EN]] — source Markdown.
- [[Historical Replay Proposal EN]] — detailed discovery scope.
- [English project page](https://pointofart.ru/index-en.html).
- [Full public specification](https://github.com/DigitalGekko77/commodity-settlement-club).

## Follow-up rule

If there is no reply, send one short follow-up after **7–10 business days**. Do not attach the full knowledge-base ZIP to first contact. Offer it by link and provide additional documents only after the recipient identifies a responsible business, risk, legal or innovation owner.

## Current status

Five Gmail drafts with the two-page PDF attached were created on 22 July 2026. They have **not been sent** and require the author's final recipient/content approval.

## Official source links

- [India Exim Bank — Research & Analysis](https://www.eximbankindia.in/research-analysis)
- [IFSCA — FinTech](https://ifsca.gov.in/Pages/Contents/Fintech)
- [ADGM — Digital Lab](https://www.adgm.com/business-areas/fintech/the-digital-lab)
- [AFSA — FinTech Lab](https://afsa.aifc.kz/fintech/fintech-lab/)
- [CIPS — Contact Us](https://www.cips.com.cn/en/about_us/contact_us/index.html)

