---
tags: [poc, outreach, historical-replay, english, v4, canonical]
updated: 2026-07-22
---

# CTB v4 — Historical Replay Proposal

## Objective

Determine whether a selected commodity-trade corridor contains material, legally compatible multilateral offsets before committing to infrastructure, licensing or live settlement.

## Scope

- 3–7 recurring legal entities across a defined corridor;
- 6–12 months of anonymised or pseudonymised historical obligations;
- obligation value, currency, trade date, due date, legal entity, governing law, commodity, title/document state and settlement outcome;
- no live funds, no title transfer and no production deployment.

## Work packages

### 1. Data and eligibility

Agree a minimum schema, privacy boundary and exclusion taxonomy. Map obligations into legally compatible candidate netting sets. Record why every excluded obligation is not eligible.

### 2. Baseline

Reconstruct the observed gross settlement path: transfer count, value, timing, peak funding, failures, delays and reconciliation effort.

### 3. Constrained netting replay

Compute multilateral residual positions under actual maturities and currencies plus hard debit, tenor, concentration and participant limits. Reproduce every run from signed inputs and versioned rules.

### 4. Legal and operational screen

Identify questions on close-out and settlement netting, insolvency, title/control, licensing, tax, AML/CFT, sanctions/export controls, data localisation and finality. This is an issue list, not a substitute for local legal opinions.

### 5. Decision pack

Report measured benefit, residual liquidity need, exceptions, model sensitivity, required risk resources, implementation dependencies and a go/no-go recommendation.

## Core measures

- `netting ratio = 1 − residual settlement value / gross eligible obligations`;
- reduction in peak liquidity and transfer count;
- eligible share of the original obligation graph;
- concentration and persistent-surplus exposure;
- title, data, legal and operational exceptions;
- estimated total cost only after collateral, integration and compliance are included.

## Evidence gates after replay

A shadow pilot proceeds only if there are committed anchor participants, material measured benefit, a credible legal route, verifiable title evidence, settlement exits, risk owners and a sponsor willing to fund the next gate. Live settlement additionally requires signed rules, funded resources, tested recovery and independent review.

## Deliverables

1. Reproducible replay workbook/data report.
2. Corridor scorecard and exception register.
3. Legal-opinion question set by jurisdiction.
4. Risk and default-resource outline.
5. Go/no-go memo for a shadow pilot.

## Initial request

Nominate a business owner and a risk/legal contact for a 30-minute scoping call. No confidential data is requested at the first meeting.

