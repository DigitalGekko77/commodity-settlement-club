---
tags: [strategy, faq, english, v4, canonical]
updated: 2026-07-22
---

# CTB v4 FAQ

### Is CTB a new currency or a SWIFT replacement?

No. CBU is a valuation convention and CTB is a netting/orchestration layer. Residual settlement uses a lawful rail selected by the participants.

### Is it sanctions-proof?

No system can guarantee that. CTB screens participants and dependencies, supports controlled continuity and makes jurisdictional risk explicit. It does not legitimise prohibited trade.

### What backs an ADC?

Verified control over an identified commodity lot or recognised ETR. Future production capacity does not back ADC and no claim is issued before evidence exists.

### Why not use only CIPS, CBDC or stablecoins?

Those are settlement rails. CTB's separate value is eligibility, multilateral netting, title evidence, risk limits and a common audit trail. It can integrate with a rail rather than compete with it.

### Why at least three parties?

Two parties only test bilateral settlement. CTB's distinctive hypothesis is that a graph of three or more recurring obligations can reduce gross transfers and peak liquidity.

### Are fees 0.3% and settlement under 72 hours guaranteed?

No. They were v3.3 targets. v4 measures total cost and legal time-to-finality against a real baseline during replay and pilot.

### Does AI make compliance or default decisions?

No. AI detects anomalies and organises evidence. Authorised humans make consequential decisions and every override is logged.

### Does CTB hide trades from regulators?

No. It uses selective disclosure: participants receive commercial confidentiality while regulators and auditors receive lawful, role-based access.

### Why not automatically convert a default into bonds?

That changes the creditor's claim and may create a regulated security. Restructuring requires consent, a rulebook and applicable-law analysis.

### Why exclude AALI, MARF and compute from the core?

An AI labour index is not enforceable collateral; a universal fund recreates a central issuer and mutual guarantee; compute-hours are not yet sufficiently standardised. They may be researched as optional modules without endangering settlement core.
