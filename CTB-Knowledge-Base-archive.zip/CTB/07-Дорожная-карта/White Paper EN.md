---
tags: [strategy, white-paper, english, v4, canonical]
updated: 2026-07-22
---

# CTB v4 White Paper

## A Regulated Multilateral Commodity Clearing Club

**Version:** 4.0 · **Author:** Igor Komkov · **Date:** 22 July 2026 · **Status:** implementation design, not a live FMI

## Abstract

Cross-border commodity trade often settles as a sequence of gross bilateral payments even where three or more participants hold offsetting obligations. CTB v4 proposes a rule-bound coordination layer that validates eligible obligations, computes multilateral net positions and links residual settlement to prefunded balances and verified commodity title. It is rail-agnostic and can use lawful bank, CIPS, CBDC or regulated stablecoin rails. It does not claim immunity from sanctions, law, infrastructure failure or credit loss.

## 1. Design thesis

The core product is **netting plus finality**, not token issuance. A useful pilot must show that eligible obligations form a graph with material multilateral offsets after timing, currency, legal-entity, title and regulatory constraints. A two-country pilot cannot test this hypothesis.

## 2. Instrument separation

CBU is a valuation convention. PSB is segregated prefunding. ADC is a claim against an identified, controlled commodity lot. ETR is the electronic document that may transfer title/control where applicable law recognises functional equivalence. A ledger entry does not itself create a warehouse receipt or bankruptcy-remoteness.

Where goods do not yet exist, CTB records a purchase/delivery obligation against PSB escrow. It does not issue ADC. Once title/control, quantity, quality, insurance and lien status are verified, ADC can be issued and exchanged delivery-versus-payment.

## 3. Netting engine

Obligations are grouped only into legally compatible netting sets. A deterministic optimiser minimises peak funding needs, number of residual transfers, liquidity stress and concentration penalties subject to debit caps, DvP and participant limits. Every run publishes an inputs hash, exclusions with reason codes, signatures and reproducible outputs.

The primary metric is `1 − net settlement value / gross eligible obligations`. No target range is promised before historical replay.

## 4. Risk and default

Margin is calibrated from market risk, liquidation horizon, basis, freight, quality, concentration and model uncertainty. Hard debit and tenor caps stop persistent surplus accumulation. The waterfall uses defaulter resources, enforceable guarantees or insurance, operator skin-in-the-game, a capped prefunded mutual layer and only then pre-agreed recovery tools. An automatic conversion into bonds is excluded: it would alter contractual rights and may issue a regulated security without consent.

## 5. Oracle and title evidence

Commodity valuation combines reference benchmark, basis, quality, freight, FX and timestamp adjustment. Sources are screened for liquidity, governance, availability and dependency. Fallbacks are instrument-specific; a trailing average does not automatically replace a broken market. Delivery evidence comes from contractually accountable warehouses, carriers and inspectors and is checked for uniqueness, control and integrity.

## 6. Privacy, compliance and AI

Commercial confidentiality uses encryption, private data partitions, role-based fields, retention rules and audited emergency access. Regulators and auditors retain lawful access. Zero-knowledge proofs are an optional tool for narrow predicates, not a promise of anonymity.

AI may reconcile documents, resolve entities, detect anomalous prices/routes/relationships and prioritise cases. Human authorities retain issuance, freeze, price override, limit change and default decisions. Models require data lineage, validation, drift monitoring and rollback.

## 7. Technology and resilience

The pilot uses one permissioned technology selected through an architecture decision record and benchmark; blockchain is not mandatory. State channels, sharding, bridges and a second consensus network are excluded. Critical operations target safe resumption within two hours and completion by end of day, with offline-signed recovery packages and tested reconciliation.

## 8. Corridor and delivery roadmap

Candidate corridors pass a weighted scorecard covering real netting potential, participant commitment, legal finality, AML/sanctions/export control, title verification, oracle depth, settlement exits, data residency and sponsor capacity. Discovery uses historical replay and a thin-slice prototype. Shadow mode precedes a capped live pilot. Expansion requires signed production rules, funded resources, independent security/model/legal review and demonstrated economics.

## 9. Deferred options

Service delivery claims, compute-hours, trade finance, post-quantum hybrid signatures and a limited liquidity facility remain modular research tracks. They cannot enter the CBU or settlement core until they demonstrate standardisation, enforceability, liquidity and operational control. A demographic/AI labour index is not collateral and is excluded from issuance.

## 10. Conclusion

v4 deliberately removes spectacular but unprovable promises. The resulting system is narrower and more valuable: stakeholders can identify the instrument, the owner of each risk, the evidence required at each gate, the source of finality and the precise conditions under which the project should stop.

## Primary references

- [CPMI-IOSCO PFMI](https://www.bis.org/cpmi/info_pfmi.htm)
- [UNCITRAL MLETR](https://uncitral.un.org/en/texts/ecommerce/modellaw/electronic_transferable_records)
- [FATF Recommendation 16 update, June 2025](https://www.fatf-gafi.org/en/publications/Fatfrecommendations/update-Recommendation-16-payment-transparency-june-2025.html)
- [NIST FIPS 204 — ML-DSA](https://csrc.nist.gov/pubs/fips/204/final)
